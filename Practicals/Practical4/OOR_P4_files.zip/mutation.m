function route_out = mutation(route,data)
% Choose two random mutation locations
??
% Generate the mutated route by swapping the cities at the random
% positions.
??
% Accept the mutated route if it is shorter that the original (hint: need 
% to call tsp_distance here).
??
end
