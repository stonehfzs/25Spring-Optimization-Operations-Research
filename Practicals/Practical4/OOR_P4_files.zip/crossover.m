function offspring = crossover(parent1,parent2)
    % Choose a random crossover point, 1 <= n_crossover <= (n_cities-2)
    n_crossover = ??
    % Create a place to store the offspring:
    offspring = nan(size(parent1));
    % Keep the first n_crossover entries from Parent 1, then scan Parent 2
    % to find the rest of the route.
    ??
end
